
<?php // Script 6.7 - handle_reg.php #6
/* This script receives seven values from register.html:
email, password, confirm, year, terms, color, submit */

// Address error management, if you want.

// initialize message which will be a string concatenation:
$msg = "<p class=error>Please <a href='javascript: history.back()'>GO BACK</a> and fill in the following errors: </p>\n\r";

// Flag variable to track success:
$okay = true;

// Validate the email address:
if (empty($_POST['email'])) {
	$msg .= "\t<span class=error>Email address must be filled in</span><br>\n\r";
	$okay = false;
}

// Validate the password:
if (empty($_POST['password'])) {
    $msg .= "\t<span class=error>Password must be filled in</span><br>\n\r";
	$okay = false;
}

// Check the two passwords for equality:
if ($_POST['password'] != $_POST['confirm']) {
	$msg .= "\t<span class=error>Passwords do not match</span><br>\n\r";
	$okay = false;
}

// Validate the year:
if ( is_numeric($_POST['year']) AND (strlen($_POST['year']) == 4) ) {

	// Check that they were born before 2016.
	if ($_POST['year'] < 2016) {
		$age = 2016 - $_POST['year']; // Calculate age this year.
	} else {
		$msg .= "\t<span class=error>Age is in the future</span><br>\n\r";
		$okay = false;
	} // End of 2nd conditional.
	
} else { // Else for 1st conditional.

	$msg .= "\t<span class=error>Age must be 4 digits</span><br>\n\r";
	$okay = false;

} // End of 1st conditional.

// Validate the terms:
if ( !isset($_POST['terms'])) {
	$msg .= "\t<span class=error>You must accept the terms</span><br>\n\r";
	$okay = false;	
}

// Validate the color:
if ($_POST['color'] == 'red') {
	$color_type = 'primary';
} elseif ($_POST['color'] == 'yellow') {
	$color_type = 'primary';
} elseif ($_POST['color'] == 'green') {
	$color_type = 'secondary';
} elseif ($_POST['color'] == 'blue') {
	$color_type = 'primary';
} else { // Problem!
	$msg .= "\t<span class=error>You must select a color</span>";
	$okay = false;
}

// If there were no errors, print a success message:
if ($okay) {
	$msg = "<p>You have been successfully registered (but not really).</p>\n\r";
	$msg .= "\t<p>You will turn $age this year.</p>\n\r";
	$msg .= "\t<p>Your favorite color is a $color_type color.</p>";
}
?>

<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Registration</title>
	<style type="text/css" media="screen">
		.error { color: red; }
	</style>
</head>
<body>
<h1>Registration Results</h1>

<div> 
    <?php echo $msg ?> 
 </div>

</body>
</html>